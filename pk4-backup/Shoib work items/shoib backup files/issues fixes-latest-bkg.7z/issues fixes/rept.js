function exec_rept (doc, into_div) {
	var piv_str;
	var last_piv_upd = '';
	var init_piv_obj;
	var cht_str;
	var last_cht_upd = '';
	var example = 'line-basic';
	var theme = 'default';
	var date_format="dd/MM/yyyy";

	var dataTblHdr = doc.dataTblHdr;
	var dataTblData = doc.dataTblData;
	var adHchart = doc.adHchart;
	var pivot_jsn = doc.pivot_json;
	var pivot_fld = doc.pivot_fields;


	$('head').append('<style type="text/css"> .filterIconCont {position:absolute; z-index: 0; width: 75px; height: 30px; background: url(\'/atCRM/images/gear.png\') no-repeat center center;} th:hover .popUpForSelFilt {display:block;} .popUpForSelFilt {position:absolute;background-color:white;color:black;font-weight:bold;font-size:12px;padding:3px;display:none;border: solid 3px rgb(31, 177, 31);border-radius: 3px;margin-top:-1.5%;z-index:1;} .dataTables_filter {width: 360px; } .removeCol {display:none;} .showOrHideColsActv { height: 250px !important; background-color: white;border: solid 2px white;border-radius: 3px; background-position:top left !important; overflow-x:hidden !important; overflow-y:auto !important; width:220px !important; margin-left: -12.5% !important;} .toggleColNameActv:before {content:\'\\2713\\0020\' !important; font-size: 14px; font-weight:bold;} .toggleColName:before {content: \"X \";font-size: 14px; font-weight:bold;} .toggleColName:hover {background-color:rgb(164, 198, 218);} .toggleColName { width: 100%; cursor: pointer; font-size: 12px; font-family: candara; display:block;margin: 2px 0;text-decoration:underline;text-align:left;padding: 2px 0;} #reportData_filter input { display: inline;} #reportData_length label { width 260px; } #reportData_length select { display: inline-block; } #tabs-min { background: transparent; border: none; } #showOrHideCols { transition: height all 1s; -webkit-transition: all 1s; -moz-transition: all 1s; -o-transition: all 1s; z-index:1; overflow: hidden; position:absolute; width:20px; margin: 0.5% 0 0 -1%; padding: 25px 4px 2px 4px; box-sizing: border-box; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; -o-box-sizing: border-box; -ms-box-sizing: border-box; height: 30px; background-image: url(\"/atCRM/images/gear.png\"); background-position: top right; background-repeat: no-repeat; } #tabs-min .ui-widget-header { background: transparent; border: none; border-bottom: 1px solid #c0c0c0; -moz-border-radius: 0px; -webkit-border-radius: 0px; border-radius: 0px; } #tabs-min .ui-state-default { background: transparent; border: none; } #tabs-min .ui-state-active { border: none; } #tabs-min .ui-state-default a { color: #c0c0c0; } #tabs-min .ui-state-active a { color: #459E00; } .dataTables_wrapper { font-size: 9pt; } .blueButton { background-color: #4982AB; border-color: #D9DFEA #0E1F5B #0E1F5B #D9DFEA; border-style: solid; border-width: 1px; color: white; cursor: pointer; font-family: "lucida grande",tahoma,verdana,arial,sans-serif; font-size: 12px; } .tabUpArr { position: absolute; bottom: -5%; left: 36%; visibility: hidden; } .ui-tabs-selected .tabUpArr {visibility: visible; }  .flash{ padding-top:4px; padding-bottom:4px; background-color: #FFFF33; font-weight:bold; font-size:12px;-moz-border-radius: 6px;-webkit-border-radius: 6px; color: black; } .alignRight { text-align: right; } li {top: 0px !important; } .ui-tabs .ui-tabs-nav { margin: 0; padding: 0 0 0 0.4em; border: 1px solid #d4ccb0; background: none !important;} .blkSdw {box-shadow: 1px 1px 4px black;-moz-box-shadow: 1px 1px 4px black;-webkit-box-shadow: 1px 1px 4px black;-o-box-shadow: 1px 1px 4px black;}</style>');

	into_div.innerHTML = '<div id="reportElementHeader"> <table width="100%"> <tr> <td align="left" class="pageTitle" width="30%"> ' + doc.ReportName + ' </td><td width="50%" align="left">' + doc.ReportDesc + '</td><td align="right" valign="bottom" width="15%"> <input type="button" class="blueButton" value="Export" style="width: 100px;" id="expxlb" /> </td> </tr> </table> </div> <div id="tabs-2"> <div id="tabs-min" class="tabs ui-tabs ui-widget ui-widget-content ui-corner-all"> <ul class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all"> <li class="ui-tabs-selected ui-state-active"> <a href="#tabData"> Data</a> <img src="/atCRM/stylesheets/style_h/images/uiTabsArrow.png" class="tabUpArr" /> </li> <li> <a href="#tabPivot"> Pivot</a> <img src="/atCRM/stylesheets/style_h/images/uiTabsArrow.png" class="tabUpArr" /></li> </ul> <div id="tabData"> <table id="reportData"> </table> </div> <div id="tabPivot" width="auto"> <div id="pivot-menu-container">Please select the appropriate columns below to create your own Pivot Report.<br> </div> <div id="k_results" style="display:inline-block"></div><div id="results"> </div> </div> </div> </div> <form name="xlForm" id="xlForm" style="display: none" action="http://sys.impelcrm.in:81/ret_xl.php" onclick="ExportToExcel(\'reportData\')" method="post"><textarea name="rN" id="rN" style="display: none"></textarea><textarea name="rD" id="rD" style="display: none"></textarea></form>';
	/*
		* reload btn
		<td align="right" valign="bottom" width="15%"> <input type="button" class="blueButton" value="Reload" style="width: 100px;" id="rel_page" > </td>
	*/
/*  Set up the tabs for Data, Chart and Pivot  */
	$('#tabs-min').tabs();

/*  Set up the datatable that carries tabular data  */
	var json_str = JSON.stringify(dataTblData);
	$(document).ready(function() {
	

		$('#expxlb').click(function() {
			ExportToExcel('reportData');
		});

		var oTable = $('#reportData').dataTable({
			"aaData": dataTblData,
			"aoColumns": dataTblHdr,
			"sDom": "\"<clear>\"frtip",
			//"aoColumnDefs": [{"sClass": "dpass", "aTargets": [0]}],
			"aaSorting": [[0, 'asc']],
			"oLanguage": {
				"sSearch": "Search all columns:"
			}
		});

		//add header names in show or hide block
		//this block toggels the display
		$('.dataTables_filter').prepend('<div id="showOrHideCols" ></div>');
		var hn;
		$('#reportData thead tr:first-child th').each(function(i) {
			hn = '<span class="toggleColName toggleColNameActv" id="'+i+'">' + $(this).text() + '</a>';
			$('#showOrHideCols').append(hn);
		});

		//show or hide col
		$('body').on('click', '.toggleColName', function() {
			var colId = $(this).attr('id');
			if($(this).hasClass('toggleColNameActv')) {
				//hide column
				$('#reportData tr').each(function() {
					$(this).find("th:eq("+colId+")").addClass('removeCol');
					$(this).find("td:eq("+colId+")").addClass('removeCol');
				});
				
				$(this).removeClass('toggleColNameActv')
			} 
			else {
				//show the column
				$('#reportData tr').each(function() {
					$(this).find("th:eq("+colId+")").removeClass('removeCol');
					$(this).find("td:eq("+colId+")").removeClass('removeCol');
				});
				
				$(this).addClass('toggleColNameActv')
			}
		});

		$('body').on('click', '#showOrHideCols', function() {

			if($(this).hasClass('showOrHideColsActv'))
				$(this).removeClass('showOrHideColsActv').removeClass('blkSdw');
			else
				$(this).addClass('showOrHideColsActv').addClass('blkSdw');;
		});

		$('#rel_page').click(function() {
			console.log('write the code for reloading');
		});

/* Add a select menu for each TH element in the table header */
		var ths = $('#reportData').children('thead').children('tr').children('th').length;
		var sel_row = $('thead').append('<tr></tr>');

		for (var ix=0; ix < ths; ix++) {
			$('thead:last tr').append("<th></th>");
		}

		$('thead tr:last th').each( function ( i ) {
			this.innerHTML = fnCreateSelect( oTable.fnGetColumnData(i), i );
			$('select', this).change( function () {
				oTable.fnFilter( $(this).val(), i );
			} );
		} );

/*  Set up the chart
	onScrChart = new Highcharts.Chart(adHchart); */
/*  Set up the Kruchten pivot table */
	$(function(){
		var derivers = $.pivotUtilities.derivers;
		var piv_jason = doc.piv_json;

		$(function(mps) {
			$("#k_results").pivotUI(piv_jason, {
				derivedAttributes: {
				}
			});
		});
	 });

/*  Set up the pivot table
	var example = 'line-basic',
		theme = 'default';
	setupPivot({json:pivot_jsn, fields:pivot_fld});
	init_piv_obj = pivot.config(true); */

	} );

}

function getSersType(value) {
	if (value = 1) {return(window.cmb_1 ? cmb_1 : "line");}
	else if (value = 2) {return(window.cmb_2 ? cmb_2 : "line");}
	else if (value = 3) {return(window.cmb_3 ? cmb_3 : "line");}
	else if (value = 4) {return(window.cmb_4 ? cmb_4 : "line");}
	else if (value = 5) {return(window.cmb_5 ? cmb_5 : "line");}
	else if (value = 6) {return(window.cmb_6 ? cmb_6 : "line");}
}

function changeType(chart, newType, chgItem) {
   var serie;
   var chgSer = chgItem;
   var currType = "";
   
   for(var i = 0; i < chart.series.length; i++)
   {
   serie = chart.series[i];
   if (newType != 'none') {
	   i == chgSer ? currType = newType : currType = serie.type;

	   chart.addSeries({
		  type: currType,
		  name: serie.name,
		  data: serie.options.data
	   }, false);
	   
	   serie.remove(false);
   }
   }
   
   chart.redraw();
}

function setupPivot(input){
	input.callbacks = {afterUpdateResults: function(){
	  $('#res_table').dataTable({
		"iDisplayLength": 50,
		"aLengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
		"bRetrieve": true,
		"oLanguage": {
		  "sLengthMenu": "_MENU_ records per page"
		}
	  });
	}};
	$('.stop-propagation').click(function(event){event.stopPropagation();});
	$('#pivot-menu-container').pivot_display('setup', input);
}


(function($) {
/*
 * Function: fnGetColumnData
 * Purpose:  Return an array of table values from a particular column.
 * Returns:  array string: 1d data array 
 * Inputs:   object:oSettings - dataTable settings object. This is always the last argument past to the function
 *           int:iColumn - the id of the column to extract the data from
 *           bool:bUnique - optional - if set to false duplicated values are not filtered out
 *           bool:bFiltered - optional - if set to false all the table data is used (not only the filtered)
 *           bool:bIgnoreEmpty - optional - if set to false empty values are not filtered from the result array
 * Author:   Benedikt Forchhammer <b.forchhammer /AT\ mind2.de>
 */
$.fn.dataTableExt.oApi.fnGetColumnData = function ( oSettings, iColumn, bUnique, bFiltered, bIgnoreEmpty ) {
	// check that we have a column id
	if ( typeof iColumn == "undefined" ) return new Array();
	
	// by default we only want unique data
	if ( typeof bUnique == "undefined" ) bUnique = true;
	
	// by default we do want to only look at filtered data
	if ( typeof bFiltered == "undefined" ) bFiltered = true;
	
	// by default we do not wany to include empty values
	if ( typeof bIgnoreEmpty == "undefined" ) bIgnoreEmpty = true;
	
	// list of rows which we're going to loop through
	var aiRows;
	
	// use only filtered rows
	if (bFiltered == true) aiRows = oSettings.aiDisplay; 
	// use all rows
	else aiRows = oSettings.aiDisplayMaster; // all row numbers

	// set up data array	
	var asResultData = new Array();
	
	for (var i=0,c=aiRows.length; i<c; i++) {
		iRow = aiRows[i];
		var aData = this.fnGetData(iRow);
		var sValue = aData[iColumn];
		
		// ignore empty values?
		if (bIgnoreEmpty == true && sValue.length == 0) continue;

		// ignore unique values?
		else if (bUnique == true && jQuery.inArray(sValue, asResultData) > -1) continue;
		
		// else push the value onto the result data array
		else asResultData.push(sValue);
	}
	
	return asResultData;
}} (jQuery));

var hdrVal;
function fnCreateSelect( aData, indx ) {
	//this will take the header value from first row of thead, based on index
	hdrVal = $('#reportData thead tr').find('th:eq('+indx+')').text();

	var r='<th><div class="popUpForSelFilt blkSdw">'+hdrVal+'</div><div class="filterIconCont" ></div><select style="width: 75px; z-index: 1; margin-bottom: 0px; opacity: 0;"><option value=""></option>', i, iLen=aData.length;
	for ( i=0 ; i<iLen ; i++ ) {
		r += '<option value="'+aData[i]+'">'+aData[i]+'</option>';
	}
	return r+'</select></th>';
}


/* 
	* Shoib Md
	* reading html data from the table and adding it to new html string
	* some assumptions are made like, first row of thead will contain header
	* javascript download excel
*/
function ExportToExcel(mytblId)
    {

       	htmlData = returnExcelFormatData(mytblId);  //will return html string
    	
       	var uri = 'data:application/vnd.ms-excel;base64,'
		    , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body>{table}</body></html>'
		    , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
		    , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) };
		
		var ctx = {worksheet: name || 'Worksheet', table: htmlData};
		window.location.href = uri + base64(format(template, ctx));
    }

//returns data as html formated string ex '<table><thead>bla</thead><tbody>bla</tbody></table>'
function returnExcelFormatData(id) {
	var tbl = '<table><thead><tr>';

	//form the thead
	var th='', txt;
	$('#'+id+' thead tr:first-child th').each(function() {
		txt = $(this).text();
		if(txt != '')
			th += '<th>' + $(this).text() + '</th>';		
	});
	tbl += th + '</tr></thead>';
	
	//form the tbody
	var tbody = '<tbody>', tr='', td='';
	var rows = $('#'+id).dataTable().fnGetNodes(); //note this get all the rows in body
	
	for(row in rows) {
		$(rows[row]).children('td').each(function() {
			txt = $(this).text();
			if(txt != '')
				td += '<td>'+ txt + '</td>';
		});
		tr += '<tr>' + td + '</tr>';
	}
	tbody += tr + '</tbody>';
	tbl += tbody + '</table>';
	return tbl;
}




function stripJSc (s) {
    var div = document.createElement('div');
    div.innerHTML = s;
    var scripts = div.getElementsByTagName('script');
    var i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }

    var imgs = div.getElementsByTagName('img');
    var i = imgs.length;
    while (i--) {
      imgs[i].parentNode.removeChild(imgs[i]);
    }

    var ayes = div.getElementsByTagName('a');
    var i = ayes.length;
    while (i--) {
      ayes[i].parentNode.removeChild(ayes[i]);
    }

    var inputs = div.getElementsByTagName('input');
    var i = inputs.length;
    while (i--) {
      inputs[i].parentNode.removeChild(inputs[i]);
    }

   return div.innerHTML;
}

